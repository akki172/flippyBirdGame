const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 800;
canvas.height = 500;

const bird = {
  x: 150,
  y: 200,
  width: 40,
  height: 40,
  gravity: 0.5,
  velocity: 0,
  jump: -10,
};

const birdImage = new Image();
birdImage.src = "https://w7.pngwing.com/pngs/907/801/png-transparent-flappy-bird-sprite-2d-computer-graphics-bird-game-animals-smiley-thumbnail.png";

const pipes = [];
const pipeWidth = 50;
const pipeGap = 150;
const pipeSpeed = 2;
const pipeInterval = 90;
let frame = 0;

let score = 0;
let gameOver = false;

document.addEventListener("keydown", (e) => {
  if (e.code === "Space" && !gameOver) {
    bird.velocity = bird.jump;
  }
});

function generatePipes() {
  if (frame % pipeInterval === 0) {
    const pipeHeight = Math.random() * (canvas.height / 2) + 50;
    pipes.push({
      x: canvas.width,
      top: pipeHeight,
      bottom: canvas.height - pipeHeight - pipeGap,
      passed: false, // Track if the pipe has been passed by the bird
    });
  }
}

function drawBird() {
  ctx.drawImage(birdImage, bird.x, bird.y, bird.width, bird.height);
}

function drawPipes() {
  ctx.fillStyle = "green";
  pipes.forEach((pipe) => {
    ctx.fillRect(pipe.x, 0, pipeWidth, pipe.top);
    ctx.fillRect(pipe.x, canvas.height - pipe.bottom, pipeWidth, pipe.bottom);
  });
}

function movePipes() {
  pipes.forEach((pipe, index) => {
    pipe.x -= pipeSpeed;

    // Check if the pipe has been passed
    if (!pipe.passed && bird.x > pipe.x + pipeWidth) {
      pipe.passed = true;
      score++; // Increase score when bird passes the pipe
    }

    if (pipe.x + pipeWidth < 0) {
      pipes.splice(index, 1); // Remove pipes that are out of view
    }
  });
}

function checkCollisions() {
  pipes.forEach((pipe) => {
    if (
      bird.x < pipe.x + pipeWidth &&
      bird.x + bird.width > pipe.x &&
      (bird.y < pipe.top || bird.y + bird.height > canvas.height - pipe.bottom)
    ) {
      gameOver = true;
    }
  });
  if (bird.y + bird.height > canvas.height || bird.y < 0) {
    gameOver = true;
  }
}

function gameLoop() {
  if (gameOver) {
    showRestartPopup();
    return;
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  drawBird();
  drawPipes();

  bird.velocity += bird.gravity;
  bird.y += bird.velocity;

  generatePipes();
  movePipes();

  checkCollisions();

  frame++;

  ctx.font = "20px Arial";
  ctx.fillStyle = "yellow";
  ctx.fillText(`Score: ${score}`, 10, 30);

  requestAnimationFrame(gameLoop);
}

function showRestartPopup() {
  const popup = document.getElementById("restartPopup");
  const finalScore = document.getElementById("finalScore");
  finalScore.textContent = score;
  popup.style.display = "block";
}

function restartGame() {
  const popup = document.getElementById("restartPopup");
  popup.style.display = "none";
  bird.y = 200;
  bird.velocity = 0;
  pipes.length = 0;
  score = 0;
  frame = 0;
  gameOver = false;
  gameLoop();
}

birdImage.onload = () => {
  gameLoop();
};
